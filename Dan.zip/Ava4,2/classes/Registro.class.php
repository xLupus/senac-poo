<?php

require_once("DatabaseConnection.class.php");
require_once("src/PHPMailer.php");
require_once("src/SMTP.php");
require_once("src/Exception.php");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

class Registro extends DatabaseConnection{
    private $id_cli;
    private $login;
    private $email;
    private $telefone;
    private $validado;
    private $codAcesso;
    private $tipo;

    public function setUsuario($login, $email, $telefone)
    {
        $this->login    = $login;
        $this->email    = $email;
        $this->telefone = $telefone;
    }

    public function setRegistrar()
    {
        $mail = new PHPMailer(true);
        $conn = $this->setConnection();

        for ($i = 0; $i < 6; $i++) {
            $this->codAcesso .= rand(0, 9);
        }

        $stmt = $conn->prepare("INSERT INTO usuarios (login, email, telefone, codAcesso, validado, tipo)
                                VALUES (?, ?, ?, ?, '0', '0')");

        $stmt->bind_param('ssss', $this->login, $this->email, $this->telefone, $this->codAcesso);

        if($stmt->execute()){
            $mail->isSMTP();
            $mail->SMTPAuth   = true;
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;

            $mail->Host       = 'smtp.hostinger.com';
            $mail->Username   = 'temporario@topsecuritty.com';
            $mail->Password   = '@#Els2556';
            $mail->Port       = 465;

            $mail->setFrom ('temporario@topsecuritty.com');
            $mail->addAddress($this->email, $this->login);
            $mail->Subject    = 'Senha';
            $mail->Body       = '<strong>'. $this->codAcesso . '</strong>';
            $mail->AltBody    = 'Texto sem HTML ou link';

            if ( !$mail->send() ){
                echo 'Não foi possível enviar o email.<br>';
            }
        }
        $stmt->close();
    }

    public function setLogin($login, $codAcesso){
        $mysqli = $this->setConnection();

        $stmt = $mysqli->prepare("SELECT * FROM usuarios where login=? ");
        $stmt->bind_param('s', $login);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_array()) {
            if($row['codAcesso'] == $codAcesso)
                return true;
            else
                return false;
        }else
            return false;
    }



    public function setValidar($user, $senha){
        $mysqli = $this->setConnection();

        $stmt = $mysqli->prepare("SELECT * FROM usuarios where login=? ");
        $stmt->bind_param('s', $user);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_array()){

            if ($row['codAcesso'] == $senha) {
                $validade = $mysqli->prepare("UPDATE usuarios SET validado = 1 where login=? ");
                $validade->bind_param('s', $user);
                if ($validade->execute()) {
                    echo "Codigo validado com Sucesso<br>
                        <a href='index.html'>Voltar</a>
                    ";
                }else
                    echo "Usuario ou Codigo de Acesso invalido";
            } else
                echo "Usuario ou Codigo de Acesso invalido";
        }
    }
}
