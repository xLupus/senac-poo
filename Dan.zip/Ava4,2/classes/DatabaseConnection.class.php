<?php

class DatabaseConnection{
    public $DB_HOST;
    public $DB_NAME;
    public $DB_USER;
    public $DB_PASS;

    public function setConnection(){
        try {
            $mysqli = new mysqli('localhost', 'Lupus', 'SL-221B-VAS', 'protocolo');
            return $mysqli;

        } catch (\Exception $e) {
            echo $e;
        }
    }

}
